"""
Tests unitaires de la logique pure (sans matériel).

Lancer en local sur un PC pour vérifier la cohérence des modules :
    python3 -m tests.test_logic_unit
"""

import math
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from navigation import geo_utils, layline, polar, potential_field, vmg
from navigation.heading_pid import HeadingPID
from navigation.waypoints import CourseManager
from comms.protocol import (
    PositionMessage, WindMessage, parse_message, build_position_from_telemetry,
)


class TestGeoUtils(unittest.TestCase):
    """Tests des utilitaires GPS."""

    def test_distance_haversine(self):
        # Deux points GPS — différence latitude de 0.001° ≈ 111 m
        p1 = (43.0967, 5.9533)
        p2 = (43.0977, 5.9533)
        d = geo_utils.distance_m(p1, p2)
        self.assertAlmostEqual(d, 111.0, delta=2.0)
        # Même point → distance 0
        self.assertAlmostEqual(geo_utils.distance_m(p1, p1), 0.0)

    def test_bearing_cardinal(self):
        # Nord : longitude identique, latitude supérieure
        p_origin = (43.0967, 5.9533)
        p_north = geo_utils.move_meters(p_origin, 0.0, 100.0)
        self.assertAlmostEqual(geo_utils.bearing_deg(p_origin, p_north), 0.0, delta=0.1)
        # Est : longitude supérieure
        p_east = geo_utils.move_meters(p_origin, 100.0, 0.0)
        self.assertAlmostEqual(geo_utils.bearing_deg(p_origin, p_east), 90.0, delta=0.1)
        # Sud
        p_south = geo_utils.move_meters(p_origin, 0.0, -100.0)
        self.assertAlmostEqual(geo_utils.bearing_deg(p_origin, p_south), 180.0, delta=0.1)
        # Ouest
        p_west = geo_utils.move_meters(p_origin, -100.0, 0.0)
        self.assertAlmostEqual(geo_utils.bearing_deg(p_origin, p_west), 270.0, delta=0.1)

    def test_offset_meters_roundtrip(self):
        p1 = (43.0967, 5.9533)
        for east, north in [(100, 0), (0, 100), (-50, 30), (200, -150)]:
            p2 = geo_utils.move_meters(p1, east, north)
            de, dn = geo_utils.offset_meters(p1, p2)
            self.assertAlmostEqual(de, east, delta=0.05)
            self.assertAlmostEqual(dn, north, delta=0.05)

    def test_destination_point(self):
        p = (43.0967, 5.9533)
        # 100m vers l'est
        p2 = geo_utils.destination_point(p, 90.0, 100.0)
        d = geo_utils.distance_m(p, p2)
        self.assertAlmostEqual(d, 100.0, delta=0.5)

    def test_gps_local_roundtrip(self):
        # gps_to_local et local_to_gps sont des outils — vérifier qu'ils sont cohérents
        lat0 = config.ORIGIN_LAT + 0.001
        lon0 = config.ORIGIN_LON + 0.001
        e, n = geo_utils.gps_to_local(lat0, lon0)
        lat2, lon2 = geo_utils.local_to_gps(e, n)
        self.assertAlmostEqual(lat0, lat2, places=6)
        self.assertAlmostEqual(lon0, lon2, places=6)

    def test_angle_diff(self):
        self.assertAlmostEqual(geo_utils.angle_diff_deg(10, 350), 20.0)
        self.assertAlmostEqual(geo_utils.angle_diff_deg(350, 10), -20.0)
        # 180 est un cas limite : peut être +180 ou -180 (équivalents)
        self.assertAlmostEqual(abs(geo_utils.angle_diff_deg(180, 0)), 180.0)


class TestPolar(unittest.TestCase):
    def test_dead_zone(self):
        # Sous l'angle min → vitesse nulle
        v = polar.boat_speed_predicted(20.0, 5.0)
        self.assertAlmostEqual(v, 0.0)

    def test_speed_increases_with_wind(self):
        v1 = polar.boat_speed_predicted(60.0, 3.0)
        v2 = polar.boat_speed_predicted(60.0, 6.0)
        self.assertGreater(v2, v1)

    def test_optimal_upwind(self):
        opt = polar.optimal_upwind_angle(5.0)
        self.assertGreater(opt, 35.0)
        self.assertLess(opt, 60.0)

    def test_sail_trim_monotonic(self):
        # La voile s'ouvre quand le vent passe de la face vers l'arrière
        prev = polar.sail_trim_percent(0)
        for awa in range(10, 180, 10):
            curr = polar.sail_trim_percent(awa)
            self.assertGreaterEqual(curr, prev - 0.01)
            prev = curr


class TestVMG(unittest.TestCase):
    def test_upwind_returns_two_options(self):
        # Vent d'est (90°), waypoint à l'est → upwind, deux options de tack
        boat = (43.0967, 5.9533)
        waypoint = geo_utils.move_meters(boat, 50.0, 0.0)  # 50m à l'est
        advice = vmg.compute_optimal_heading(
            boat_pos=boat,
            waypoint=waypoint,
            true_wind_dir_deg=90.0,
            true_wind_speed_ms=5.0,
            current_heading_deg=45.0,
        )
        self.assertEqual(advice.regime, "UPWIND")
        self.assertTrue(advice.needs_tacking)

    def test_reaching(self):
        # Vent d'ouest, waypoint au nord → travers
        boat = (43.0967, 5.9533)
        waypoint = geo_utils.move_meters(boat, 0.0, 50.0)  # 50m au nord
        advice = vmg.compute_optimal_heading(
            boat_pos=boat,
            waypoint=waypoint,
            true_wind_dir_deg=270.0,
            true_wind_speed_ms=5.0,
            current_heading_deg=0.0,
        )
        self.assertEqual(advice.regime, "REACHING")

    def test_apparent_wind(self):
        # Bateau immobile → vent apparent = vent réel
        awa, awa_speed = vmg.true_to_apparent_wind(
            true_wind_dir_deg=90.0,
            true_wind_speed_ms=5.0,
            boat_heading_deg=0.0,
            boat_speed_ms=0.0,
        )
        self.assertAlmostEqual(awa_speed, 5.0)
        # AWA = vent vient à 90° du nord → bateau cap nord →
        # vent apparent vient de la droite (+90°)
        self.assertAlmostEqual(awa, 90.0, places=1)


class TestProtocol(unittest.TestCase):
    def test_position_roundtrip(self):
        msg = PositionMessage("U1B1", 43.48256, 6.49872, 185, 3.2, no_fix=False)
        text = msg.encode()
        self.assertTrue(text.startswith("P|U1B1"))
        parsed = parse_message(text)
        self.assertIsInstance(parsed, PositionMessage)
        self.assertEqual(parsed.boat_id, "U1B1")
        self.assertAlmostEqual(parsed.lat, 43.48256, places=4)
        self.assertAlmostEqual(parsed.lon, 6.49872, places=4)
        self.assertEqual(parsed.heading_deg, 185)

    def test_wind_roundtrip(self):
        msg = WindMessage(245, 6.3, 1746787652, sensor_offline=False)
        text = msg.encode()
        parsed = parse_message(text)
        self.assertIsInstance(parsed, WindMessage)
        self.assertEqual(parsed.direction_deg, 245)
        self.assertAlmostEqual(parsed.speed_ms, 6.3, places=1)

    def test_no_fix(self):
        msg = build_position_from_telemetry(
            "U1B2", 0, 0, 0, 0, has_fix=False,
        )
        self.assertTrue(msg.no_fix)
        text = msg.encode()
        self.assertEqual(text, "P|U1B2|0|0|0|0")

    def test_negative_lat_lon(self):
        # Le PDF spécifie int32 ×1e5 — peut être négatif
        msg = PositionMessage("U1B1", -43.48256, -6.49872, 0, 0, no_fix=False)
        text = msg.encode()
        parsed = parse_message(text)
        self.assertAlmostEqual(parsed.lat, -43.48256, places=4)
        self.assertAlmostEqual(parsed.lon, -6.49872, places=4)


class TestCourse(unittest.TestCase):
    def test_initial_state(self):
        cm = CourseManager()
        self.assertEqual(cm.current_idx, 0)
        self.assertFalse(cm.race_started)
        self.assertEqual(cm.current_leg.name, "DEPART")

    def test_progression(self):
        # Simuler qu'on franchit la porte A-B en GPS
        cm = CourseManager()
        # Position 30m à l'est de la porte
        a = config.BUOYS_GPS["A"]
        b = config.BUOYS_GPS["B"]
        gate_mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        # On part à 30m est de la porte, on traverse en allant 30m ouest
        before = geo_utils.move_meters(gate_mid, 30.0, 0.0)
        after = geo_utils.move_meters(gate_mid, -30.0, 0.0)
        cm.update_and_validate(before)
        cm.update_and_validate(after)
        self.assertTrue(cm.race_started)
        self.assertEqual(cm.current_leg.name, "ETAPE_1_C")


class TestPID(unittest.TestCase):
    def test_zero_error(self):
        pid = HeadingPID()
        out = pid.compute(target_heading_deg=90.0, current_heading_deg=90.0)
        self.assertAlmostEqual(out, 0.0)

    def test_positive_error_right_rudder(self):
        pid = HeadingPID()
        # Cap voulu 100°, cap actuel 90° → erreur +10° → safran à droite
        out = pid.compute(target_heading_deg=100.0, current_heading_deg=90.0)
        self.assertGreater(out, 0)

    def test_saturation(self):
        pid = HeadingPID()
        # Erreur énorme
        out = pid.compute(target_heading_deg=180.0, current_heading_deg=0.0)
        self.assertLessEqual(abs(out), config.RUDDER_ANGLE_MAX_DEG + 0.01)


class TestPotentialField(unittest.TestCase):
    def test_attractive_only(self):
        boat = (43.0967, 5.9533)
        waypoint = geo_utils.move_meters(boat, 10.0, 0.0)   # 10m à l'est
        f = potential_field.attractive_force(boat, waypoint, gain=1.0)
        # Force unitaire vers l'est
        self.assertAlmostEqual(f[0], 1.0, places=2)
        self.assertAlmostEqual(f[1], 0.0, places=2)

    def test_repulsive_close(self):
        boat = (43.0967, 5.9533)
        rep_pos = geo_utils.move_meters(boat, 2.0, 0.0)   # 2m à l'est du bateau
        rep = potential_field.Repulsor(pos=rep_pos, radius_m=4.0, gain=10.0)
        f = potential_field.repulsive_force(boat, rep)
        # Force répulsive → pousse le bateau vers l'OUEST (x négatif)
        self.assertLess(f[0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
