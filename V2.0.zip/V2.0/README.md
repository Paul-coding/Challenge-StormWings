# StormWings — Challenge SWARMz BattleBoats 2026

> Système de navigation autonome multi-drones voiliers pour le Challenge SWARMz BattleBoats organisé à Toulon les 9-10 mai 2026 par l'**équipe UTT (Université de Technologie de Troyes)**.

---

## 🎯 Objectif

Faire courir 3 voiliers radio-commandés Joysway Focus V2 (~1 m, ID UTT : `U1B1`, `U1B2`, `U1B3`) **en pilotage autonome coopératif** sur le parcours N°3 (9 waypoints), face à 3 équipes adverses (DaVinci, IPSA, ENSEEIHT). La station-sol diffuse le vent par LoRa, les drones se coordonnent en mode TDMA, et un opérateur peut reprendre la main à tout moment via un levier RC.

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  STATION-SOL                   │  À BORD DU DRONE              │
│  ───────────────               │  ────────────────             │
│  Calypso anémomètre            │                               │
│  ESP32 LoRa (Tx vent)          │                               │
│           │                    │                               │
│           │  W|dir|spd|ts      │                               │
│           ▼                    │                               │
│      LoRa 868 MHz ─────────────┼─► ESP32 LoRa V3               │
│                                │       │ Meshtastic            │
│                                │       │ /dev/ttyUSB0          │
│                                │       ▼                       │
│  Télécommande RC               │   Raspberry Pi 4B             │
│  ┌───────┐                     │   ┌─────────────────────┐     │
│  │ CH1: gouvernail │           │   │ main.py             │     │
│  │ CH2: voile      │           │   │  ├── navigation/    │     │
│  │ CH3: AUTO/MAN   │           │   │  ├── comms/         │     │
│  │ CH4: boost      │           │   │  ├── safety/        │     │
│  └───────┘                     │   │  └── swarm/         │     │
│       │  PPM                   │   └─────────────────────┘     │
│       ▼                        │       │ MAVLink 57600 baud    │
│   PCB embarqué ────────────────┼──►    ▼ /dev/serial0          │
│                                │   Cube Orange+ ArduRover 4.6.3│
│                                │       │ PWM                   │
│                                │       ▼                       │
│                                │   Servo gouvernail (OUT1)     │
│                                │   Servo voile (OUT2)          │
│                                │   Boost moteur (OUT4)*        │
│                                │                               │
│                                │   *uniquement sur U1B1        │
└─────────────────────────────────────────────────────────────────┘
```

## 📂 Arborescence

```
stormwings/
├── main.py                    # Boucle principale 10 Hz
├── config.py                  # ⚠️ Différencie les 3 drones via DRONE_ID
├── requirements.txt
├── README.md                  # ce fichier
│
├── navigation/                # Cerveau du voilier
│   ├── geo_utils.py           #   Conversions GPS ↔ local, distance, bearing
│   ├── polar.py               #   Polaire de vitesse Joysway (empirique)
│   ├── vmg.py                 #   VMG, vent apparent, cap optimal
│   ├── layline.py             #   Détection layline + décision tack
│   ├── waypoints.py           #   CourseManager (parcours N°3, 9 étapes)
│   ├── potential_field.py     #   Anti-collision Khatib
│   ├── heading_pid.py         #   PID de cap → angle de safran
│   └── state_machine.py       #   ATTENTE → EN_COURSE → ARRIVÉE
│
├── comms/                     # Communications
│   ├── mavlink_iface.py       #   Wrapper pymavlink (RC override, télémetrie)
│   ├── protocol.py            #   Trames LoRa officielles (W|… et P|…)
│   └── lora_iface.py          #   Wrapper Meshtastic
│
├── wind/                      # Estimation vent
│   └── wind_estimator.py      #   Fusion Calypso + lissage + fallback
│
├── swarm/                     # Coordination essaim
│   ├── roles.py               #   Scout / Optimizer / Safety dynamique
│   └── tdma.py                #   Slots TDMA décalés par drone
│
├── safety/                    # Sécurités et modes dégradés
│   ├── mode_switch.py         #   Bascule MANUEL ↔ AUTO via CH3
│   ├── degraded_modes.py      #   GPS_LOST, LORA_LOST, WIND_STALE…
│   └── logger.py              #   Logger CSV ~30 colonnes
│
├── boost/                     # Moteur électrique (U1B1 uniquement)
│   └── boost_controller.py    #   3 × 30 s max, auto-check vent mort
│
├── tests/                     # Validation
│   ├── test_logic_unit.py     #   22 tests unitaires (logique pure)
│   ├── test_connexion.py      #   Sanity hardware (MAVLink + LoRa)
│   ├── test_servos.py         #   Sweep gauche/centre/droite + voile
│   └── test_bascule.py        #   Vérification CH3 manuel ↔ auto
│
├── tools/                     # Utilitaires
│   ├── gps_buoy_survey.py     #   (optionnel) Vérif/relevé GPS RTK des bouées
│   ├── replay_log.py          #   Visualisation post-course
│   └── simulator.py           #   Simulateur 2D parcours N°3
│
├── docs/                      # Documentation
│   ├── ardupilot_params.txt   #   Paramètres Cube Orange+ (à charger)
│   ├── ARDUPILOT_PARAMS.md    #   Explications détaillées
│   └── CABLAGE.md             #   Schéma de câblage (CH4 boost)
│
└── scripts/                   # Déploiement
    ├── install.sh             #   Installation Pi (UART, deps, systemd)
    └── stormwings.service     #   Service systemd
```

## 🚀 Démarrage rapide

### Sur PC (vérification logique, sans matériel)

```bash
git clone <repo> stormwings
cd stormwings
pip install -r requirements.txt

# Tests unitaires (22 tests)
python3 -m tests.test_logic_unit

# Simulateur (parcours complet en ~7 minutes simulées)
python3 -m tools.simulator --wind-dir 90 --wind-speed 5
```

### Sur Raspberry Pi 4B (déploiement réel)

```bash
# 1. Installation système (UART, deps, systemd)
sudo bash scripts/install.sh
sudo reboot

# 2. Définir l'identifiant du drone
echo 'DRONE_ID=U1B1' | sudo tee /etc/stormwings/drone_id.env
# (U1B1 = Scout avec moteur boost, U1B2 = Optimizer, U1B3 = Safety)

# 3. Tests hardware (dans cet ordre, bateau hors de l'eau pour test_servos)
DRONE_ID=U1B1 python3 -m tests.test_connexion
DRONE_ID=U1B1 python3 -m tests.test_servos
DRONE_ID=U1B1 python3 -m tests.test_bascule

# 4. Lancement manuel (debug)
DRONE_ID=U1B1 python3 main.py

# 4 bis. OU via systemd (production)
sudo systemctl start stormwings
sudo journalctl -u stormwings -f
```

## ⚙️ Configuration des 3 drones

Le fichier **`config.py`** ajuste tous les paramètres en fonction de la variable d'environnement `DRONE_ID` :

| ID    | Rôle initial | Boost moteur | Slot TDMA |
|-------|-------------|--------------|-----------|
| U1B1  | **Scout** — éclaireur, prend les risques | ✅ Oui | t+0 s |
| U1B2  | **Optimizer** — meilleur VMG, le plus rapide | ❌ Non | t+20 s |
| U1B3  | **Safety** — couverture, anti-collision | ❌ Non | t+40 s |

Les rôles sont **dynamiques** : un drone peut devenir Scout si le Scout original est en panne (cf. `swarm/roles.py`).

## 📡 Protocole LoRa officiel

Le protocole utilisé est celui défini par `BATTLEBOATS_LORA_PROTOCOL_v5.pdf` :

- **Vent** : `W|dir|spd|ts` (ASCII pipe-séparé, émis par la station Calypso)
- **Position** : `P|id|lat|lon|hdg|spd` (lat/lon en `int32 × 1e5`)

Toutes les trames sont **broadcast** sur le canal `BATTLEBOATS`.

## 🛡️ Sécurité — bascule manuel/auto

À tout moment, l'opérateur peut **reprendre la main** en levant le levier CH3 :

- **CH3 < 1 300 µs** → Mode AUTO (Pi pilote via `RC_CHANNELS_OVERRIDE`)
- **CH3 > 1 500 µs** → Mode MANUEL (RC physique reprend la main)
- Hystérésis pour éviter l'oscillation à la transition

Le Cube Orange+ reste **en permanence en mode MANUAL** ArduPilot. C'est le Pi qui choisit s'il envoie ou pas des overrides.

## 📊 Modes dégradés

Le système surveille en continu l'état des sous-systèmes et bascule automatiquement :

| Mode | Déclencheur | Réaction |
|------|-------------|----------|
| `GPS_LOST` | Pas de fix > 5 s | Cap au compas, vitesse estimée |
| `LORA_LOST` | Plus de trame depuis > 10 s | Vent par défaut (E 4,5 m/s) |
| `WIND_STALE` | Vent vieux de > 30 s | Idem |
| `LOW_BATTERY` | Tension < 11,1 V | Désactive boost, ralentit |
| `MAVLINK_LOST` | Pas de heartbeat > 3 s | Pause des commandes |

## 🧪 Validation

- **22 tests unitaires** sur la logique pure (geo, polaire, VMG, layline, PID, anti-collision, protocole)
- **Simulateur 2D** : course finie en 7 min 30 s sur 990 m avec vent E 5 m/s
- **Tests hardware** dédiés à la connexion, aux servos et à la bascule manuel/auto

## 📝 Tâches à faire avant le 9 mai

- [ ] Le matin de la course : recevoir les coordonnées GPS officielles des bouées des organisateurs
- [ ] **Éditer `config.BUOYS_GPS`** avec ces coordonnées (un seul dictionnaire à modifier)
- [ ] **Calibration ArduPilot** dans Mission Planner (RADIO + ACCEL + COMPASS)
- [ ] Charger `docs/ardupilot_params.txt` dans chaque Cube
- [ ] Calibration polaire de vitesse sur l'eau
- [ ] Test essaim (3 drones simultanés) en eau calme

> **Note sur les coordonnées :** la navigation runtime travaille **directement
> en GPS (lat, lon)** sans passer par un repère local. Cela évite toute dérive
> liée à un point d'origine et simplifie l'édition matinale : un seul dictionnaire
> à modifier dans `config.py`. L'outil `tools/gps_buoy_survey.py` reste disponible
> en plan B si une vérification croisée est nécessaire sur l'eau.

## 📜 Crédits

- **Équipe UTT** : conception, développement, intégration
- **PoC SwarmZ** (`SwarmZ-main.zip`) : référence pour les paramètres ArduPilot
- **Joysway Focus V2** : voilier RC IOM 1 m
- **ArduRover 4.6.3** sur Cube Orange+
- **Meshtastic** sur ESP32 LoRa V3 (868 MHz)

## 📄 Licence

Projet académique UTT pour le Challenge SWARMz 2026. Reproduction libre dans un cadre éducatif.
