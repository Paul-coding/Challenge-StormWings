"""
StormWings — point d'entrée principal.

Ce fichier implémente le SCHÉMA DÉCISIONNEL de decision_flowchart.py :

    INIT → ATTENTE → EN_COURSE [APPROCHE / REMONTEE / DESCENTE] → FIN

Cycle 100 ms (10 Hz) :
    1. Lecture capteurs (MAVLink + LoRa + vent)
    2. Détection urgence (collision imminente, perte mavlink)
    3. Bascule MANUEL ↔ AUTO selon CH3
    4. Si AUTO :
        a. Mise à jour rôle (Scout/Optimizer/Safety)
        b. Calcul plan waypoint courant
        c. Calcul cap optimal VMG (avec laylines)
        d. Anti-collision champ de potentiel
        e. PID cap → angle safran → PWM CH1
        f. Réglage voile selon angle vent apparent → PWM CH2
        g. Boost auto si conditions
    5. Push override CH1/CH2 (et CH4 si boost)
    6. Comm LoRa : envoi P|... toutes les 60s décalées par TDMA
    7. Logging CSV
    8. Sleep jusqu'au prochain tick

Lancement :
    DRONE_ID=U1B1 python3 main.py        # drone Scout (avec boost)
    DRONE_ID=U1B2 python3 main.py        # drone Optimizer
    DRONE_ID=U1B3 python3 main.py        # drone Safety
"""

import logging
import math
import os
import signal
import sys
import time
from typing import Optional

# Permettre l'import des sous-modules en mode développement
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from boost.boost_controller import BoostController, BoostState
from comms.lora_iface import LoRaInterface
from comms.mavlink_iface import MavlinkInterface
from navigation import geo_utils, layline, polar, potential_field, vmg
from navigation.heading_pid import HeadingPID
from navigation.state_machine import NavState, NavStateMachine
from navigation.waypoints import CourseManager
from safety.degraded_modes import DegradedManager, DegradedMode
from safety.logger import FlightLogger
from safety.mode_switch import ControlMode, ModeSwitch
from swarm.roles import RoleManager
from swarm.tdma import TDMAScheduler
from wind.wind_estimator import WindEstimator


# ──────────────────────────────────────────────────────────────────
# Logging setup
# ──────────────────────────────────────────────────────────────────
def setup_logging():
    log_dir = config.LOG_DIR
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"stormwings_{config.DRONE_ID}.log")
    logging.basicConfig(
        level=getattr(logging, config.LOG_LEVEL),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler(sys.stdout),
        ],
    )


# ──────────────────────────────────────────────────────────────────
# Application
# ──────────────────────────────────────────────────────────────────
class StormWingsApp:
    """Application principale."""

    def __init__(self):
        self.log = logging.getLogger("StormWings")
        self.running = False

        # Composants matériels
        self.mav = MavlinkInterface()
        self.lora: Optional[LoRaInterface] = None

        # Composants logiques
        self.nav_sm = NavStateMachine()
        self.course = CourseManager()
        self.heading_pid = HeadingPID()
        self.mode_switch: Optional[ModeSwitch] = None
        self.wind = WindEstimator()
        self.roles = RoleManager()
        self.tdma = TDMAScheduler()
        self.degraded = DegradedManager()
        self.boost = BoostController(self.mav)
        self.flight_log = FlightLogger()

        # Compteurs / timing
        self._last_tack_t: float = 0.0
        self._last_comm_t: float = 0.0
        self._last_override_push_t: float = 0.0
        self._last_heartbeat_t: float = 0.0
        self._last_sail_pct: float = 50.0
        self._target_heading_deg: float = 0.0
        self._last_rudder_cmd_deg: float = 0.0
        self._last_role_eval_t: float = 0.0

    # ─────────────────────────────────────────────
    # Setup / Teardown
    # ─────────────────────────────────────────────
    def setup(self) -> bool:
        self.log.info("=" * 60)
        self.log.info("StormWings %s — démarrage", config.DRONE_ID)
        self.log.info("Rôle initial : %s | Boost : %s",
                      config.DEFAULT_ROLE, config.HAS_BOOST_MOTOR)
        self.log.info("=" * 60)

        # MAVLink (obligatoire)
        if not self.mav.connect(timeout_s=30.0):
            self.log.error("Impossible de se connecter au Cube Orange+")
            return False
        self.mode_switch = ModeSwitch(self.mav)

        # LoRa (optionnel mais fortement recommandé)
        try:
            self.lora = LoRaInterface()
            if not self.lora.connect():
                self.log.warning(
                    "LoRa indisponible — navigation sans coordination essaim"
                )
                self.lora = None
            else:
                # Branchement des callbacks vent
                self.lora.on_wind = self._on_wind_received
                self.lora.on_position = self._on_position_received
        except Exception as e:
            self.log.warning("LoRa init échoué : %s", e)
            self.lora = None

        # Logger CSV
        self.flight_log.open()

        # Initialisation des composants
        self.nav_sm.transition(NavState.INIT, "boot")

        return True

    def teardown(self):
        self.log.info("Arrêt en cours…")
        try:
            self.mav.clear_all_overrides()
        except Exception:
            pass
        try:
            self.flight_log.close()
        except Exception:
            pass
        try:
            if self.lora is not None:
                self.lora.close()
        except Exception:
            pass
        try:
            self.mav.close()
        except Exception:
            pass
        self.log.info("StormWings %s — arrêt complet", config.DRONE_ID)

    # ─────────────────────────────────────────────
    # Callbacks LoRa
    # ─────────────────────────────────────────────
    def _on_wind_received(self, msg):
        self.wind.push_calypso(
            direction_deg=msg.direction_deg,
            speed_ms=msg.speed_ms,
            timestamp=msg.timestamp,
            sensor_offline=msg.sensor_offline,
        )

    def _on_position_received(self, msg):
        # Repère local pour les calculs
        if msg.no_fix:
            return
        east, north = geo_utils.gps_to_local(msg.lat, msg.lon)
        if config.is_teammate(msg.boat_id):
            spd_ms = msg.speed_knots / 1.94384
            self.roles.update_teammate(
                boat_id=msg.boat_id,
                pos_local=(east, north),
                speed_ms=spd_ms,
                has_fix=not msg.no_fix,
            )

    # ─────────────────────────────────────────────
    # Boucle principale
    # ─────────────────────────────────────────────
    def run(self):
        if self.mode_switch is None:
            raise RuntimeError("setup() doit être appelé avant run()")

        self.running = True
        next_tick = time.monotonic()

        try:
            while self.running:
                self._tick()
                # Cadence 10 Hz
                next_tick += config.NAV_DT
                sleep = next_tick - time.monotonic()
                if sleep > 0:
                    time.sleep(sleep)
                else:
                    # On a pris du retard → reset le ref pour ne pas drifter
                    next_tick = time.monotonic()
        except KeyboardInterrupt:
            self.log.info("Interruption clavier")
        finally:
            self.teardown()

    def _tick(self):
        now = time.monotonic()

        # ===== 1. LECTURE TÉLÉMÉTRIE =====
        tlm = self.mav.get_telemetry()
        wind_est = self.wind.estimate()
        active_neighbors = self.lora.get_team_neighbors() if self.lora else {}

        # Position locale (East, North)
        if tlm.has_gps_fix:
            east, north = geo_utils.gps_to_local(tlm.lat, tlm.lon)
            boat_pos = (east, north)
        else:
            boat_pos = (0.0, 0.0)

        # ===== 2. HEARTBEAT GCS (anti-failsafe) =====
        if now - self._last_heartbeat_t >= 1.0:
            self.mav.send_heartbeat()
            self._last_heartbeat_t = now

        # ===== 3. ÉTAT DÉGRADÉ =====
        last_gps_age = (now - tlm.last_gps_t) if tlm.last_gps_t > 0 else 1e9
        deg = self.degraded.update(
            has_gps_fix=tlm.has_gps_fix,
            gps_fix_type=tlm.fix_type,
            last_gps_age_s=last_gps_age,
            wind_age_s=wind_est.age_s,
            wind_confident=wind_est.confident,
            num_active_neighbors=len(active_neighbors),
            battery_pct=tlm.battery_remaining_pct,
            mavlink_alive=self.mav.is_alive(),
        )

        # Si MAVLink perdu → on n'envoie plus rien (sécurité)
        if deg.has(DegradedMode.MAVLINK_LOST):
            self.log.warning("MAVLink perdu — pause des commandes")
            self.nav_sm.transition(NavState.DEGRADE, "mavlink_lost")
            self._comm_step(tlm, wind_est, now)
            self._log_step(tlm, wind_est, deg, active_neighbors, now)
            return

        # ===== 4. BASCULE MANUEL/AUTO =====
        mode_status = self.mode_switch.update()

        # ===== 5. ROUTAGE ÉTAT NAVIGATION =====
        if mode_status.mode == ControlMode.MANUAL:
            # Téléopérateur en contrôle — Pi observe seulement
            self.nav_sm.transition(NavState.REPRISE_RC, "ch3 haut")
            self._update_self_state(boat_pos, tlm)
        elif mode_status.mode == ControlMode.UNKNOWN:
            # CH3 non encore reçu — sécurité : on ne pilote pas
            self.nav_sm.transition(NavState.ATTENTE, "ch3 inconnu")
            self.mav.clear_all_overrides()
        else:
            # AUTO
            self._auto_step(boat_pos, tlm, wind_est, active_neighbors, now)

        # ===== 6. ENVOI DES OVERRIDES (10 Hz) =====
        if self.mode_switch.is_auto:
            if now - self._last_override_push_t >= 1.0 / config.OVERRIDE_REFRESH_HZ:
                self.mav.push_overrides()
                self._last_override_push_t = now

        # ===== 7. COMM LORA =====
        self._comm_step(tlm, wind_est, now)

        # ===== 8. LOGGING =====
        self._log_step(tlm, wind_est, deg, active_neighbors, now)

    # ─────────────────────────────────────────────
    # Étape AUTO complète
    # ─────────────────────────────────────────────
    def _auto_step(self, boat_pos, tlm, wind_est, active_neighbors, now):
        # Mise à jour de l'état du parcours
        if tlm.has_gps_fix:
            self.course.update_and_validate(boat_pos)
            self._update_self_state(boat_pos, tlm)

        # Réévaluation du rôle
        if now - self._last_role_eval_t >= config.ROLE_REEVAL_PERIOD_S:
            self.roles.reevaluate()
            self._last_role_eval_t = now

        # Course terminée ?
        if self.course.race_finished:
            self.nav_sm.transition(NavState.FIN_COURSE, "porte arrivée")
            self.mav.set_rudder_pwm(config.RUDDER_PWM_TRIM)
            self.mav.set_sail_percent(50.0)
            return

        # Pas encore démarrée ?
        if not self.course.race_started:
            # On peut être en attente du signal de départ
            self.nav_sm.transition(NavState.ATTENTE, "pré-départ")
            # En attente, on garde le bateau à l'arrêt mais réactif
            self._auto_idle(tlm, wind_est)
            return

        # Plan immédiat
        plan = self.course.plan(boat_pos)
        if plan is None:
            self.log.warning("Pas de plan disponible")
            return

        # ── Calcul cap optimal VMG ──
        advice = vmg.compute_optimal_heading(
            boat_pos=boat_pos,
            waypoint=plan.target_pos,
            true_wind_dir_deg=wind_est.direction_deg,
            true_wind_speed_ms=wind_est.speed_ms,
            current_heading_deg=tlm.heading_deg,
        )

        # ── Régime de navigation ──
        if advice.regime == "UPWIND":
            self.nav_sm.transition(NavState.REMONTEE_VENT, "vmg")
        elif advice.regime == "DOWNWIND":
            self.nav_sm.transition(NavState.DESCENTE, "vmg")
        elif advice.regime == "REACHING":
            self.nav_sm.transition(NavState.REACHING, "vmg")

        # ── Layline / décision tack ──
        target_heading = advice.target_heading_deg

        if advice.regime == "UPWIND":
            ll = layline.evaluate(
                boat_pos=boat_pos,
                boat_heading_deg=tlm.heading_deg,
                target_buoy_pos=plan.final_pos,
                true_wind_dir_deg=wind_est.direction_deg,
                true_wind_speed_ms=wind_est.speed_ms,
            )
            time_since_last_tack = now - self._last_tack_t
            # Si layline atteinte → forcer le tack (cap opposé du VMG)
            if (ll.should_tack
                    and time_since_last_tack > config.MIN_TIME_BETWEEN_TACKS_S):
                target_heading = (
                    advice.tack_options[1] if ll.on_starboard_tack
                    else advice.tack_options[0]
                )
                self._last_tack_t = now
                self.log.info("[NAV] Tack forcé (layline atteinte) → cap %.0f°",
                              target_heading)

        # ── Anti-collision champ de potentiel ──
        # Construire la liste des répulseurs actifs (autres drones connus
        # par LoRa, alliés et ennemis)
        all_neighbors_pos = []
        if self.lora is not None:
            for bid, ns in self.lora.get_active_neighbors().items():
                if ns.has_fix:
                    e, n = geo_utils.gps_to_local(ns.lat, ns.lon)
                    all_neighbors_pos.append((bid, (e, n)))

        # Bouées proches (rayon de 10m), EXCLU la bouée que l'on vient de valider
        last_validated_buoy = None
        if self.course.current_idx > 0:
            prev_leg = self.course.legs[self.course.current_idx - 1]
            if prev_leg.completed and prev_leg.side != "gate":
                last_validated_buoy = prev_leg.buoy
        nearby_buoys = []
        for buoy_name in config.BUOYS_LOCAL:
            if buoy_name == last_validated_buoy:
                continue
            bp = geo_utils.buoy_local(buoy_name)
            if geo_utils.distance_m(boat_pos, bp) < 10.0:
                nearby_buoys.append(buoy_name)

        repulsors = potential_field.build_repulsors(
            other_drones_positions=all_neighbors_pos,
            nearby_buoys=nearby_buoys,
        )

        # Détection collision imminente
        if potential_field.emergency_avoidance_needed(
            boat_pos, repulsors, threshold_m=3.0
        ):
            self.nav_sm.transition(NavState.EVITEMENT_URGENCE, "obstacle <3m")
            # Le cap est alors entièrement dicté par le champ de potentiel
            f = potential_field.total_force(
                boat_pos=boat_pos,
                waypoint=plan.target_pos,
                repulsors=repulsors,
                attractive_gain=0.5,    # on diminue l'attraction
            )
            target_heading = potential_field.force_to_heading(f)
            # Sécurité : ne pas envoyer le bateau en zone morte
            target_heading = potential_field.safe_heading_against_wind(
                target_heading, wind_est.direction_deg,
                config.POLAR_THETA_MIN_DEG,
            )
        else:
            # Modulation douce du cap par le champ de potentiel
            if repulsors:
                f = potential_field.total_force(
                    boat_pos=boat_pos,
                    waypoint=plan.target_pos,
                    repulsors=repulsors,
                    attractive_gain=2.0,
                )
                pf_heading = potential_field.force_to_heading(f)
                # Mélange : 80% VMG, 20% champ de potentiel
                # (sauf si l'écart est important — alors on suit le PF)
                diff = geo_utils.angle_diff_deg(pf_heading, target_heading)
                if abs(diff) > 30:
                    # Bouée ou drone très proche → on suit le PF
                    # mais en évitant la zone morte
                    target_heading = potential_field.safe_heading_against_wind(
                        pf_heading, wind_est.direction_deg,
                        config.POLAR_THETA_MIN_DEG,
                    )

        # ── PID cap → angle safran ──
        rudder_cmd_deg = self.heading_pid.compute(
            target_heading_deg=target_heading,
            current_heading_deg=tlm.heading_deg,
        )
        self.mav.set_rudder_angle_deg(rudder_cmd_deg)
        self._last_rudder_cmd_deg = rudder_cmd_deg
        self._target_heading_deg = target_heading

        # ── Réglage voile selon angle vent apparent ──
        awa_deg, _ = vmg.true_to_apparent_wind(
            true_wind_dir_deg=wind_est.direction_deg,
            true_wind_speed_ms=wind_est.speed_ms,
            boat_heading_deg=tlm.heading_deg,
            boat_speed_ms=tlm.ground_speed_ms,
        )
        sail_pct = polar.sail_trim_percent(awa_deg)
        # Lissage pour éviter de fatiguer le winch
        sail_pct = 0.7 * self._last_sail_pct + 0.3 * sail_pct
        self._last_sail_pct = sail_pct
        self.mav.set_sail_percent(sail_pct)

        # ── Boost auto (uniquement Scout par défaut) ──
        role_mods = self.roles.role_modifies_strategy()
        in_dead = polar.is_dead_zone(
            geo_utils.angle_diff_deg(target_heading, wind_est.direction_deg)
        )
        boost_status = self.boost.update(
            boat_speed_ms=tlm.ground_speed_ms,
            wind_speed_ms=wind_est.speed_ms,
            battery_pct=tlm.battery_remaining_pct,
        )
        self.boost.auto_check(
            boat_speed_ms=tlm.ground_speed_ms,
            wind_speed_ms=wind_est.speed_ms,
            battery_pct=tlm.battery_remaining_pct,
            in_dead_zone=in_dead,
            role_authorizes=role_mods["use_boost_authorized"],
        )

    def _auto_idle(self, tlm, wind_est):
        """En attente de départ : safran droit, voile mi-position."""
        self.mav.set_rudder_pwm(config.RUDDER_PWM_TRIM)
        self.mav.set_sail_percent(60.0)

    def _update_self_state(self, boat_pos, tlm):
        self.roles.update_self(
            leg_index=self.course.current_idx,
            pos_local=boat_pos,
            speed_ms=tlm.ground_speed_ms,
            battery_pct=tlm.battery_remaining_pct,
            has_fix=tlm.has_gps_fix,
        )

    # ─────────────────────────────────────────────
    # Communication LoRa
    # ─────────────────────────────────────────────
    def _comm_step(self, tlm, wind_est, now):
        if self.lora is None:
            return
        if not self.tdma.should_transmit():
            return
        try:
            self.lora.broadcast_position(
                lat=tlm.lat,
                lon=tlm.lon,
                heading_deg=tlm.heading_deg,
                speed_ms=tlm.ground_speed_ms,
                has_fix=tlm.has_gps_fix,
            )
        except Exception as e:
            self.log.warning("LoRa broadcast échoué : %s", e)

    # ─────────────────────────────────────────────
    # Logging
    # ─────────────────────────────────────────────
    def _log_step(self, tlm, wind_est, deg, active_neighbors, now):
        try:
            leg = self.course.current_leg
            plan = self.course.plan(
                geo_utils.gps_to_local(tlm.lat, tlm.lon)
                if tlm.has_gps_fix else (0.0, 0.0)
            )
            east, north = (geo_utils.gps_to_local(tlm.lat, tlm.lon)
                           if tlm.has_gps_fix else (0.0, 0.0))
            row = {
                "nav_state": self.nav_sm.state.value,
                "control_mode": self.mode_switch.update().mode.value
                if self.mode_switch else "?",
                "role": self.roles.my_role,
                "leg_index": self.course.current_idx,
                "leg_name": leg.name if leg else "—",
                "lat": tlm.lat,
                "lon": tlm.lon,
                "east_m": east,
                "north_m": north,
                "heading_deg": tlm.heading_deg,
                "speed_ms": tlm.ground_speed_ms,
                "roll_deg": tlm.roll_deg,
                "wp_distance_m": plan.distance_m if plan else 0.0,
                "wp_bearing_deg": plan.bearing_deg if plan else 0.0,
                "target_heading_deg": self._target_heading_deg,
                "rudder_cmd_deg": self._last_rudder_cmd_deg,
                "rudder_pwm": self.mav._override_rudder_pwm,
                "sail_pwm": self.mav._override_sail_pwm,
                "sail_pct": self._last_sail_pct,
                "wind_dir_deg": wind_est.direction_deg,
                "wind_speed_ms": wind_est.speed_ms,
                "wind_age_s": wind_est.age_s,
                "wind_source": wind_est.source,
                "battery_pct": tlm.battery_remaining_pct,
                "boost_state": self.boost.state.value,
                "boost_used": self.boost._activations_used,
                "neighbors_count": len(active_neighbors),
                "degraded_modes": "|".join(m.value for m in deg.active_modes),
            }
            self.flight_log.log(row)
        except Exception as e:
            self.log.debug("Log err : %s", e)

    # ─────────────────────────────────────────────
    # Signaux Unix
    # ─────────────────────────────────────────────
    def install_signal_handlers(self):
        def handler(signum, frame):
            self.log.info("Signal %d reçu — arrêt", signum)
            self.running = False
        signal.signal(signal.SIGINT, handler)
        signal.signal(signal.SIGTERM, handler)


# ──────────────────────────────────────────────────────────────────
# Entrée
# ──────────────────────────────────────────────────────────────────
def main():
    setup_logging()
    app = StormWingsApp()
    app.install_signal_handlers()
    if not app.setup():
        sys.exit(1)
    app.run()


if __name__ == "__main__":
    main()
