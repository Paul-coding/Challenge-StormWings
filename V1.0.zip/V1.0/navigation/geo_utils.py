"""
Utilitaires géographiques.

Conversions GPS (lat/lon) ↔ repère local (East/North en mètres),
calcul de distances, caps, et angles relatifs.

Le repère local est défini par config.ORIGIN_LAT/ORIGIN_LON ; tout est
calculé en projection plate (équirectangulaire), valide pour des
distances < 5 km à la latitude de Toulon.
"""

import math
from typing import Tuple

import config


# Rayon terrestre moyen
EARTH_RADIUS_M = 6_371_000.0


def deg2rad(d: float) -> float:
    return d * math.pi / 180.0


def rad2deg(r: float) -> float:
    return r * 180.0 / math.pi


def gps_to_local(lat: float, lon: float) -> Tuple[float, float]:
    """Conversion GPS → (east, north) en mètres depuis l'origine.

    Args:
        lat: latitude en degrés décimaux
        lon: longitude en degrés décimaux
    Returns:
        (east_m, north_m) : x = est positif, y = nord positif
    """
    lat0 = deg2rad(config.ORIGIN_LAT)
    dlat = deg2rad(lat - config.ORIGIN_LAT)
    dlon = deg2rad(lon - config.ORIGIN_LON)
    east = dlon * math.cos(lat0) * EARTH_RADIUS_M
    north = dlat * EARTH_RADIUS_M
    return east, north


def local_to_gps(east: float, north: float) -> Tuple[float, float]:
    """Inverse de gps_to_local. Retourne (lat, lon) en degrés."""
    lat0 = deg2rad(config.ORIGIN_LAT)
    dlat = north / EARTH_RADIUS_M
    dlon = east / (math.cos(lat0) * EARTH_RADIUS_M)
    return (
        config.ORIGIN_LAT + rad2deg(dlat),
        config.ORIGIN_LON + rad2deg(dlon),
    )


def distance_m(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
    """Distance euclidienne en mètres entre deux points du repère local."""
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])


def bearing_deg(p_from: Tuple[float, float], p_to: Tuple[float, float]) -> float:
    """Cap (bearing) en degrés depuis p_from vers p_to.

    Convention NAVIGATION : 0° = nord, 90° = est, 180° = sud, 270° = ouest.
    """
    de = p_to[0] - p_from[0]
    dn = p_to[1] - p_from[1]
    # atan2(east, north) → angle depuis le nord, sens horaire
    angle = math.degrees(math.atan2(de, dn))
    return (angle + 360.0) % 360.0


def angle_diff_deg(target: float, current: float) -> float:
    """Différence d'angle signée dans [-180, +180].

    Positif si target est à droite (sens horaire) de current.
    """
    d = (target - current + 540.0) % 360.0 - 180.0
    return d


def cap_to_unit_vector(cap_deg: float) -> Tuple[float, float]:
    """Convertit un cap NAVIGATION en vecteur unitaire (east, north)."""
    rad = deg2rad(cap_deg)
    return math.sin(rad), math.cos(rad)


def buoy_local(buoy_name: str) -> Tuple[float, float]:
    """Position locale d'une bouée par son nom (ex: 'C', 'D', 'AB')."""
    if buoy_name == "AB":
        # Milieu de la porte A-B
        a = config.BUOYS_LOCAL["A"]
        b = config.BUOYS_LOCAL["B"]
        return ((a.east + b.east) / 2.0, (a.north + b.north) / 2.0)
    pos = config.BUOYS_LOCAL[buoy_name]
    return (pos.east, pos.north)


def gate_endpoints() -> Tuple[Tuple[float, float], Tuple[float, float]]:
    """Coordonnées (A, B) de la porte départ/arrivée."""
    a = config.BUOYS_LOCAL["A"]
    b = config.BUOYS_LOCAL["B"]
    return ((a.east, a.north), (b.east, b.north))


def cross_2d(v1: Tuple[float, float], v2: Tuple[float, float]) -> float:
    """Produit vectoriel 2D (composante z)."""
    return v1[0] * v2[1] - v1[1] * v2[0]


def dot_2d(v1: Tuple[float, float], v2: Tuple[float, float]) -> float:
    return v1[0] * v2[0] + v1[1] * v2[1]


def line_crossed(prev_pos: Tuple[float, float],
                 curr_pos: Tuple[float, float],
                 line_a: Tuple[float, float],
                 line_b: Tuple[float, float]) -> bool:
    """Vrai si le segment [prev_pos, curr_pos] croise le segment [line_a, line_b]."""
    d1 = cross_2d(
        (line_b[0] - line_a[0], line_b[1] - line_a[1]),
        (prev_pos[0] - line_a[0], prev_pos[1] - line_a[1]),
    )
    d2 = cross_2d(
        (line_b[0] - line_a[0], line_b[1] - line_a[1]),
        (curr_pos[0] - line_a[0], curr_pos[1] - line_a[1]),
    )
    d3 = cross_2d(
        (curr_pos[0] - prev_pos[0], curr_pos[1] - prev_pos[1]),
        (line_a[0] - prev_pos[0], line_a[1] - prev_pos[1]),
    )
    d4 = cross_2d(
        (curr_pos[0] - prev_pos[0], curr_pos[1] - prev_pos[1]),
        (line_b[0] - prev_pos[0], line_b[1] - prev_pos[1]),
    )
    return (d1 * d2 < 0) and (d3 * d4 < 0)
