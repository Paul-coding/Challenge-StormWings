"""
Gestionnaire de la séquence de waypoints du Parcours N°3.

Le parcours impose un ORDRE STRICT (cf. règlement Battleboats 2026 V2.2 et
DOSSIER_TECHNIQUE.docx) :
    Départ porte A-B → C(stbd) → D(port) → E(port) → C(stbd)
                     → F(stbd) → G(stbd) → C(stbd) → Arrivée porte A-B

Chaque étape donne :
    - waypoint visuel (point de validation)
    - waypoint d'approche (décalé de 2m de la bouée pour la contourner du
      bon côté avec la marge requise par l'utilisateur)

Validation de l'étape :
    - Pour les bouées : passer dans un rayon < WAYPOINT_VALIDATION_M
      ET du bon côté (port/starboard vérifié par produit vectoriel).
    - Pour les portes : croiser le segment A-B dans le bon sens.
"""

import math
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from . import geo_utils
import config

log = logging.getLogger(__name__)


@dataclass
class Leg:
    """Une étape du parcours."""
    name: str
    buoy: str               # "A", "B", "C", ..., ou "AB" pour la porte
    side: str               # "starboard", "port", "gate"
    completed: bool = False
    started_at: float = 0.0


@dataclass
class WaypointPlan:
    """Plan immédiat à suivre (rafraîchi à chaque tick navigation)."""
    leg: Leg
    leg_index: int
    target_pos: Tuple[float, float]      # waypoint d'approche réel
    final_pos: Tuple[float, float]       # bouée à valider
    distance_m: float
    bearing_deg: float
    is_gate: bool


class CourseManager:
    """État global du parcours, avance étape par étape."""

    def __init__(self):
        self.legs: List[Leg] = [Leg(**l) for l in config.COURSE_3_LEGS]
        self.current_idx: int = 0
        self.last_position: Optional[Tuple[float, float]] = None
        self.race_started: bool = False
        self.race_finished: bool = False

    # ─────────────────────────────────────────────
    # Accès à l'étape courante
    # ─────────────────────────────────────────────
    @property
    def current_leg(self) -> Optional[Leg]:
        if self.current_idx >= len(self.legs):
            return None
        return self.legs[self.current_idx]

    def progress_str(self) -> str:
        return f"{self.current_idx}/{len(self.legs)}"

    # ─────────────────────────────────────────────
    # Calcul du waypoint d'approche
    # ─────────────────────────────────────────────
    def _approach_point(
        self,
        buoy_pos: Tuple[float, float],
        next_buoy_pos: Tuple[float, float],
        side: str,
    ) -> Tuple[float, float]:
        """Décale la cible de BUOY_CLEARANCE_M du bon côté de la bouée.

        Le décalage est perpendiculaire à la direction "vers la bouée
        suivante", de manière à arriver à la bouée par le bon côté pour
        ensuite la contourner sans la toucher.
        """
        # Direction depuis la bouée courante vers la suivante
        dx = next_buoy_pos[0] - buoy_pos[0]
        dy = next_buoy_pos[1] - buoy_pos[1]
        norm = math.hypot(dx, dy)
        if norm < 1e-3:
            # Pas de bouée suivante (ex: dernière étape) → pas de décalage
            return buoy_pos
        ux, uy = dx / norm, dy / norm
        # Vecteur perpendiculaire :
        #  - "starboard" (bouée à droite du bateau) → on passe à GAUCHE de
        #    la bouée → le waypoint d'approche est à gauche de la ligne
        #    bouée→suivante (côté +90°).
        #  - "port" → on passe à droite → côté -90°.
        if side == "starboard":
            nx, ny = -uy, ux         # rotation +90°
        elif side == "port":
            nx, ny = uy, -ux         # rotation -90°
        else:
            return buoy_pos
        clearance = config.BUOY_CLEARANCE_M
        return (buoy_pos[0] + nx * clearance, buoy_pos[1] + ny * clearance)

    def _next_buoy_pos(self, leg_index: int) -> Tuple[float, float]:
        """Position de la bouée suivante (utile pour orienter l'approche)."""
        if leg_index + 1 < len(self.legs):
            next_buoy = self.legs[leg_index + 1].buoy
            return geo_utils.buoy_local(next_buoy)
        # Dernière étape : on retourne le centre de la porte
        return geo_utils.buoy_local("AB")

    # ─────────────────────────────────────────────
    # Plan immédiat
    # ─────────────────────────────────────────────
    def plan(self, boat_pos: Tuple[float, float]) -> Optional[WaypointPlan]:
        leg = self.current_leg
        if leg is None:
            return None
        buoy_pos = geo_utils.buoy_local(leg.buoy)
        if leg.side == "gate":
            target = buoy_pos          # milieu de la porte
            is_gate = True
        else:
            next_pos = self._next_buoy_pos(self.current_idx)
            target = self._approach_point(buoy_pos, next_pos, leg.side)
            is_gate = False
        d = geo_utils.distance_m(boat_pos, target)
        b = geo_utils.bearing_deg(boat_pos, target)
        return WaypointPlan(
            leg=leg,
            leg_index=self.current_idx,
            target_pos=target,
            final_pos=buoy_pos,
            distance_m=d,
            bearing_deg=b,
            is_gate=is_gate,
        )

    # ─────────────────────────────────────────────
    # Validation
    # ─────────────────────────────────────────────
    def update_and_validate(self, boat_pos: Tuple[float, float]) -> bool:
        """À appeler à chaque tick. Retourne True si une étape vient d'être
        validée (utile pour logger et déclencher les transitions d'état).
        """
        leg = self.current_leg
        if leg is None:
            return False

        validated = False

        if leg.side == "gate":
            # Croisement du segment A-B
            (ax, ay), (bx, by) = geo_utils.gate_endpoints()
            if self.last_position is not None:
                if geo_utils.line_crossed(
                    self.last_position, boat_pos, (ax, ay), (bx, by)
                ):
                    if leg.name == "DEPART":
                        if not self.race_started:
                            self.race_started = True
                            log.info("[COURSE] Porte de départ franchie")
                            validated = True
                    elif leg.name == "ARRIVEE":
                        if self.race_started and self.current_idx == len(self.legs) - 1:
                            self.race_finished = True
                            log.info("[COURSE] Porte d'arrivée franchie — FIN")
                            validated = True
        else:
            # Validation bouée : à moins de WAYPOINT_VALIDATION_M
            buoy_pos = geo_utils.buoy_local(leg.buoy)
            d = geo_utils.distance_m(boat_pos, buoy_pos)
            if d < config.WAYPOINT_VALIDATION_M:
                # Vérification supplémentaire : passage du bon côté
                # → produit vectoriel entre direction d'arrivée et bouée→bateau
                if self.last_position is not None and self._side_correct(
                    self.last_position, boat_pos, buoy_pos, leg.side
                ):
                    validated = True
                else:
                    # Validation avec doute → on prend quand même mais on log
                    validated = True
                    log.warning(
                        "[COURSE] Bouée %s validée mais le côté n'est pas certain",
                        leg.buoy,
                    )

        if validated:
            leg.completed = True
            log.info(
                "[COURSE] Étape validée : %s (%s/%s)",
                leg.name, self.current_idx + 1, len(self.legs),
            )
            self.current_idx += 1

        self.last_position = boat_pos
        return validated

    @staticmethod
    def _side_correct(
        prev_pos: Tuple[float, float],
        curr_pos: Tuple[float, float],
        buoy_pos: Tuple[float, float],
        side: str,
    ) -> bool:
        """Vrai si la bouée a été contournée du bon côté.

        Calcul : produit vectoriel entre la direction du bateau et le
        vecteur bateau→bouée. Signe positif = bouée à gauche.
        """
        dirx = curr_pos[0] - prev_pos[0]
        diry = curr_pos[1] - prev_pos[1]
        bx = buoy_pos[0] - curr_pos[0]
        by = buoy_pos[1] - curr_pos[1]
        cross = dirx * by - diry * bx
        if side == "starboard":
            # Bouée à droite du bateau → cross < 0
            return cross < 0
        elif side == "port":
            # Bouée à gauche → cross > 0
            return cross > 0
        return True

    def reset(self):
        for leg in self.legs:
            leg.completed = False
        self.current_idx = 0
        self.race_started = False
        self.race_finished = False
        self.last_position = None
