"""
Champ de potentiel pour anti-collision et évitement de bouées.

Combine :
    - Force ATTRACTIVE vers le waypoint courant (gain configurable, F = -k·∇U)
    - Force RÉPULSIVE des bouées (rayon BUOY_REPULSION_RADIUS_M)
    - Force RÉPULSIVE des autres drones connus (rayon DRONE_REPULSION_RADIUS_M)

La force résultante est convertie en cap recommandé. On applique ensuite
une PONDÉRATION avec le cap VMG : on ne dévie de la trajectoire optimale
que si une force répulsive significative l'exige.
"""

import math
from dataclasses import dataclass
from typing import Iterable, Tuple, List

from . import geo_utils
import config


@dataclass
class Repulsor:
    pos: Tuple[float, float]
    radius_m: float
    gain: float
    label: str = ""


def attractive_force(
    boat_pos: Tuple[float, float],
    waypoint: Tuple[float, float],
    gain: float = 1.0,
) -> Tuple[float, float]:
    """Force attractive vers le waypoint (champ conique → constant en module)."""
    dx = waypoint[0] - boat_pos[0]
    dy = waypoint[1] - boat_pos[1]
    n = math.hypot(dx, dy)
    if n < 1e-3:
        return (0.0, 0.0)
    return (gain * dx / n, gain * dy / n)


def repulsive_force(
    boat_pos: Tuple[float, float],
    repulsor: Repulsor,
) -> Tuple[float, float]:
    """Force répulsive (champ en 1/r², coupé au-delà du rayon)."""
    dx = boat_pos[0] - repulsor.pos[0]
    dy = boat_pos[1] - repulsor.pos[1]
    d = math.hypot(dx, dy)
    if d > repulsor.radius_m or d < 1e-3:
        return (0.0, 0.0)
    # Force = gain · (1/d - 1/R) / d²  · vecteur unitaire bateau→répulseur
    # Forme classique de Khatib (1986)
    coeff = repulsor.gain * (1.0 / d - 1.0 / repulsor.radius_m) / (d * d)
    return (coeff * dx / d, coeff * dy / d)


def total_force(
    boat_pos: Tuple[float, float],
    waypoint: Tuple[float, float],
    repulsors: Iterable[Repulsor],
    attractive_gain: float = 1.0,
) -> Tuple[float, float]:
    """Force totale = attractive + somme des répulsions."""
    fx, fy = attractive_force(boat_pos, waypoint, attractive_gain)
    for r in repulsors:
        rx, ry = repulsive_force(boat_pos, r)
        fx += rx
        fy += ry
    return (fx, fy)


def force_to_heading(force: Tuple[float, float]) -> float:
    """Convertit un vecteur (east, north) en cap navigation (degrés, 0=N)."""
    fx, fy = force
    if abs(fx) < 1e-6 and abs(fy) < 1e-6:
        return 0.0
    angle = math.degrees(math.atan2(fx, fy))
    return (angle + 360.0) % 360.0


def is_heading_in_dead_zone(heading_deg: float, wind_dir_deg: float,
                            dead_zone_half_deg: float = 35.0) -> bool:
    """Vrai si ce cap mettrait le bateau dans la zone morte du vent.

    Utilisé pour rejeter les caps PF qui paralyseraient le voilier.
    """
    diff = abs(((heading_deg - wind_dir_deg + 540.0) % 360.0) - 180.0)
    twa = 180.0 - diff
    return twa < dead_zone_half_deg


def safe_heading_against_wind(heading_deg: float, wind_dir_deg: float,
                              dead_zone_half_deg: float = 35.0) -> float:
    """Si heading_deg est en zone morte, renvoie le cap valide le plus proche.

    Utilisé en complément de force_to_heading pour s'assurer que le bateau
    peut effectivement avancer avec ce cap.
    """
    if not is_heading_in_dead_zone(heading_deg, wind_dir_deg, dead_zone_half_deg):
        return heading_deg
    # Trouver les deux limites de la zone morte
    limit_starboard = (wind_dir_deg + dead_zone_half_deg) % 360.0
    limit_port = (wind_dir_deg - dead_zone_half_deg) % 360.0
    # Choisir la limite la plus proche du cap demandé
    diff_s = abs(((heading_deg - limit_starboard + 540.0) % 360.0) - 180.0)
    diff_p = abs(((heading_deg - limit_port + 540.0) % 360.0) - 180.0)
    return limit_starboard if diff_s < diff_p else limit_port


def build_repulsors(
    other_drones_positions: List[Tuple[str, Tuple[float, float]]],
    nearby_buoys: List[str],
) -> List[Repulsor]:
    """Construit la liste des répulseurs actifs au tick courant.

    Args:
        other_drones_positions : liste de (id, (east, north)) — alliés ET
                                 ennemis, le champ ne fait pas la différence
                                 pour la sécurité de navigation.
        nearby_buoys : liste de noms de bouées présentes à proximité.
    """
    repulsors = []
    for boat_id, pos in other_drones_positions:
        repulsors.append(Repulsor(
            pos=pos,
            radius_m=config.DRONE_REPULSION_RADIUS_M,
            gain=config.DRONE_REPULSION_GAIN,
            label=f"drone:{boat_id}",
        ))
    for buoy_name in nearby_buoys:
        try:
            pos = geo_utils.buoy_local(buoy_name)
        except KeyError:
            continue
        repulsors.append(Repulsor(
            pos=pos,
            radius_m=config.BUOY_REPULSION_RADIUS_M,
            gain=config.BUOY_REPULSION_GAIN,
            label=f"buoy:{buoy_name}",
        ))
    return repulsors


def emergency_avoidance_needed(
    boat_pos: Tuple[float, float],
    repulsors: Iterable[Repulsor],
    threshold_m: float = 3.0,
) -> bool:
    """Retourne True si un répulseur est à moins de threshold_m
    → la boucle principale doit basculer en évitement d'urgence."""
    for r in repulsors:
        if geo_utils.distance_m(boat_pos, r.pos) < threshold_m:
            return True
    return False
