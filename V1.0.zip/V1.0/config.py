"""
StormWings — configuration centrale.

Pour différencier les 3 drones de l'équipe UTT, un seul paramètre change :
la variable d'environnement DRONE_ID qu'on règle au lancement du service systemd
(ou en CLI : `DRONE_ID=U1B2 python3 main.py`).

ID officiels (cf. BATTLEBOATS_LORA_PROTOCOL_v5.pdf, équipe UTT) :
    U1B1 → drone 1 (Scout, embarque le moteur boost)
    U1B2 → drone 2 (Optimizer)
    U1B3 → drone 3 (Safety)

IMPORTANT — paramètres ArduPilot validés PoC SwarmZ :
    Le PoC SwarmZ (PoC Full) impose SERVO1_FUNCTION=1 (RCPassThru) et
    SERVO2_FUNCTION=89 (MainSail), pas 0 comme suggéré dans le brief initial.
    Avec SERVO_FUNCTION=0 le servo est désactivé. Voir docs/ARDUPILOT_PARAMS.md.
"""

import os
from dataclasses import dataclass, field
from typing import Tuple, Dict


# ════════════════════════════════════════════════════════════════════════
# IDENTITÉ DU DRONE (différencie les 3 instances)
# ════════════════════════════════════════════════════════════════════════
DRONE_ID: str = os.environ.get("DRONE_ID", "U1B1").upper()
TEAM_ID: str = "UTT"

# Mapping ID → numéro logique dans l'essaim (1 = Scout par défaut)
_DRONE_NUM_MAP = {"U1B1": 1, "U1B2": 2, "U1B3": 3}
DRONE_NUM: int = _DRONE_NUM_MAP.get(DRONE_ID, 1)

# Liste des coéquipiers (broadcast → utile pour filtrer les voisins)
TEAM_BOATS = ("U1B1", "U1B2", "U1B3")
ENEMY_BOATS = (
    "D2B1", "D2B2", "D2B3",   # DaVinci Hive
    "I3B1", "I3B2", "I3B3",   # IPSA
    "E4B1", "E4B2", "E4B3",   # Enseeiht
)


# ════════════════════════════════════════════════════════════════════════
# MATÉRIEL EMBARQUÉ
# ════════════════════════════════════════════════════════════════════════
# UART vers Cube Orange+ (port TELEM2 du Cube → /dev/serial0 du Pi)
# Sur Pi 4B avec dtoverlay=disable-bt, /dev/serial0 → /dev/ttyAMA0
MAVLINK_PORT: str = "/dev/serial0"
MAVLINK_BAUD: int = 57600

# UART vers ESP32 LoRa V3 (Meshtastic) — branché en USB
LORA_PORT: str = "/dev/ttyUSB0"
LORA_BAUD: int = 115200      # auto-géré par Meshtastic, info seulement

# Moteur boost (uniquement sur D1 par défaut, modifiable selon montage réel)
HAS_BOOST_MOTOR: bool = (DRONE_ID == "U1B1")
# Si le moteur boost est piloté via un canal RC supplémentaire (CH4 par ex.)
BOOST_RC_CHANNEL: int = 4    # CH4 du Cube Orange+
BOOST_PWM_OFF: int = 1000    # µs — moteur arrêté
BOOST_PWM_ON: int = 1900     # µs — moteur plein régime


# ════════════════════════════════════════════════════════════════════════
# FRÉQUENCES DES BOUCLES
# ════════════════════════════════════════════════════════════════════════
NAV_LOOP_HZ: float = 10.0          # boucle navigation (capteurs + décisions)
COMM_LOOP_HZ: float = 2.0          # boucle LoRa (cf. dossier technique)
NAV_DT: float = 1.0 / NAV_LOOP_HZ
COMM_DT: float = 1.0 / COMM_LOOP_HZ

# Le protocole BattleBoats officiel impose 60s entre 2 broadcasts P|...
LORA_BROADCAST_PERIOD_S: float = 60.0


# ════════════════════════════════════════════════════════════════════════
# PROTOCOLE LORA TDMA (interne UTT, pour anti-collision radio)
# ════════════════════════════════════════════════════════════════════════
# Trame de 1500 ms divisée en 3 slots de 500 ms (cf. dossier technique)
TDMA_FRAME_MS: int = 1500
TDMA_SLOT_MS: int = 500
TDMA_SLOTS = {"U1B1": 0, "U1B2": 500, "U1B3": 1000}
MY_TDMA_OFFSET_MS: int = TDMA_SLOTS.get(DRONE_ID, 0)


# ════════════════════════════════════════════════════════════════════════
# PARCOURS N°3 — POSITIONS DES BOUÉES (référentiel local mètres)
# ════════════════════════════════════════════════════════════════════════
# Ces coordonnées sont des ESTIMATIONS issues de la photo satellite du
# Règlement Battleboats 2026 V2.2. Elles DOIVENT être remplacées par les
# vraies coordonnées GPS relevées le 8 mai sur site avec tools/gps_buoy_survey.py
#
# Origine du repère local : milieu géométrique de la porte A-B
@dataclass(frozen=True)
class BuoyPos:
    east: float    # x = est positif (mètres depuis l'origine A-B)
    north: float   # y = nord positif


BUOYS_LOCAL: Dict[str, BuoyPos] = {
    "A":  BuoyPos(80.0,  0.0),     # tribord porte départ/arrivée
    "B":  BuoyPos(80.0, -30.0),    # bâbord porte départ/arrivée
    "C":  BuoyPos(0.0,  -20.0),    # bouée centrale (visitée 3 fois)
    "D":  BuoyPos(-30.0, 20.0),    # nord-ouest de C
    "E":  BuoyPos(-80.0, 5.0),
    "F":  BuoyPos(-200.0, -60.0),  # extrémité sud-ouest
    "G":  BuoyPos(-150.0, -40.0),
    "Z1": BuoyPos(100.0, 30.0),    # zone pénalité
    "Z2": BuoyPos(100.0, 50.0),
}

# Origine GPS du repère local — Plage du Mourillon, Toulon (à raffiner sur site)
ORIGIN_LAT: float = 43.0967     # latitude décimale °
ORIGIN_LON: float = 5.9533      # longitude décimale °


# ════════════════════════════════════════════════════════════════════════
# SÉQUENCE DU PARCOURS N°3
# ════════════════════════════════════════════════════════════════════════
# (waypoint, side) où side = "starboard" → bouée à droite (tribord) du drone
#                              "port"      → bouée à gauche  (bâbord)
#                              "gate"      → franchissement de porte
#
# Description ordonnée du parcours :
#   Départ porte A-B → C(stbd) → D(port) → E(port) → C(stbd)
#                    → F(stbd) → G(stbd) → C(stbd) → Arrivée porte A-B
COURSE_3_LEGS = [
    {"name": "DEPART",       "buoy": "AB", "side": "gate"},
    {"name": "ETAPE_1_C",    "buoy": "C",  "side": "starboard"},
    {"name": "ETAPE_2_D",    "buoy": "D",  "side": "port"},
    {"name": "ETAPE_3_E",    "buoy": "E",  "side": "port"},
    {"name": "ETAPE_4_C",    "buoy": "C",  "side": "starboard"},
    {"name": "ETAPE_5_F",    "buoy": "F",  "side": "starboard"},
    {"name": "ETAPE_6_G",    "buoy": "G",  "side": "starboard"},
    {"name": "ETAPE_7_C",    "buoy": "C",  "side": "starboard"},
    {"name": "ARRIVEE",      "buoy": "AB", "side": "gate"},
]

# Marge de contournement des bouées (cf. brief utilisateur)
BUOY_CLEARANCE_M: float = 2.0       # rayon de sécurité bouée
WAYPOINT_VALIDATION_M: float = 3.0  # rayon de validation du WP atteint
GATE_HALF_WIDTH_M: float = 18.0     # demi-largeur ligne A-B (≈ 30m / 2 + marge)


# ════════════════════════════════════════════════════════════════════════
# NAVIGATION — POLAIRE DE VITESSE & VMG
# ════════════════════════════════════════════════════════════════════════
# Modèle analytique simplifié (cf. dossier technique §V.1) :
#   V_bateau(θ, V_vent) = V_vent · f(θ) · g(V_vent)
#   f(θ) = A · sin²(θ - θ_min) / (1 + B·cos²(θ))
#
# Coefficients à calibrer sur l'eau avec tools/polar_calibration.py
POLAR_THETA_MIN_DEG: float = 35.0   # angle minimum de remontée au vent
POLAR_A: float = 0.85
POLAR_B: float = 0.60

# Angle optimal de VMG remontée (estimation initiale, raffiné en ligne)
VMG_UPWIND_ANGLE_DEG: float = 45.0  # entre 42° et 48° selon force du vent

# Hystérésis pour éviter les tacks intempestifs
TACK_DECISION_HYSTERESIS_DEG: float = 8.0
MIN_TIME_BETWEEN_TACKS_S: float = 6.0   # 1 tack coûte ~3-5s de vitesse perdue


# ════════════════════════════════════════════════════════════════════════
# CHAMP DE POTENTIEL — ANTI-COLLISION INTER-DRONES
# ════════════════════════════════════════════════════════════════════════
DRONE_REPULSION_RADIUS_M: float = 4.0  # rayon d'anti-collision drone-drone
DRONE_REPULSION_GAIN: float = 30.0     # force répulsion (sans dimension)
BUOY_REPULSION_RADIUS_M: float = BUOY_CLEARANCE_M
BUOY_REPULSION_GAIN: float = 20.0


# ════════════════════════════════════════════════════════════════════════
# RÔLES DYNAMIQUES (Scout / Optimizer / Safety)
# ════════════════════════════════════════════════════════════════════════
ROLE_SCOUT: str = "SCOUT"
ROLE_OPTIMIZER: str = "OPTIMIZER"
ROLE_SAFETY: str = "SAFETY"

# Rôle initial par drone (réévalué toutes les 5s via swarm/roles.py)
DEFAULT_ROLE = {
    "U1B1": ROLE_SCOUT,
    "U1B2": ROLE_OPTIMIZER,
    "U1B3": ROLE_SAFETY,
}.get(DRONE_ID, ROLE_OPTIMIZER)

ROLE_REEVAL_PERIOD_S: float = 5.0


# ════════════════════════════════════════════════════════════════════════
# BASCULE MANUEL ↔ AUTO via CH3
# ════════════════════════════════════════════════════════════════════════
# Le levier CH3 de la J4C05 :
#   CH3 < CH3_THRESHOLD_LOW  → Pi en contrôle (mode AUTO)
#   CH3 > CH3_THRESHOLD_HIGH → RC en contrôle (mode MANUAL téléopéré)
#   Entre les deux            → état précédent conservé (hystérésis)
CH3_THRESHOLD_LOW: int = 1300        # µs
CH3_THRESHOLD_HIGH: int = 1500       # µs
CH_RUDDER: int = 1                   # CH1 → safran
CH_SAIL: int = 2                     # CH2 → voile (winch)
CH_MODE: int = 3                     # CH3 → bascule mode

# Période d'envoi continu RC_CHANNELS_OVERRIDE (Cube timeout ~0.5s)
OVERRIDE_REFRESH_HZ: float = 10.0


# ════════════════════════════════════════════════════════════════════════
# MAPPING PWM ↔ ANGLES PHYSIQUES
# ════════════════════════════════════════════════════════════════════════
# Safran : ±45° max ↔ 1100 / 1900 µs (centre 1500)
RUDDER_PWM_MIN: int = 1100
RUDDER_PWM_MAX: int = 1900
RUDDER_PWM_TRIM: int = 1500
RUDDER_ANGLE_MAX_DEG: float = 45.0

# Voile (winch) : 0% (border) → 1100 µs, 100% (choquer) → 1900 µs
SAIL_PWM_MIN: int = 1100   # voile bordée à fond (vent de face)
SAIL_PWM_MAX: int = 1900   # voile choquée à fond (vent arrière)


# ════════════════════════════════════════════════════════════════════════
# PID DU CAP (consigne envoyée au gouvernail)
# ════════════════════════════════════════════════════════════════════════
HEADING_PID_KP: float = 2.0
HEADING_PID_KI: float = 0.1
HEADING_PID_KD: float = 0.5
HEADING_PID_OUTPUT_MAX: float = 1.0    # normalisé [-1, 1] → mappé sur PWM


# ════════════════════════════════════════════════════════════════════════
# WATCHDOG / TIMEOUTS
# ════════════════════════════════════════════════════════════════════════
HEARTBEAT_TIMEOUT_S: float = 2.0          # Cube Orange+ heartbeat
GPS_FIX_TIMEOUT_S: float = 5.0
WIND_FALLBACK_TIMEOUT_S: float = 90.0     # si pas de WIND msg → fallback
LORA_NEIGHBOR_TIMEOUT_S: float = 180.0    # voisin perdu → mode solo


# ════════════════════════════════════════════════════════════════════════
# LOGGING
# ════════════════════════════════════════════════════════════════════════
LOG_DIR: str = "/home/admin/stormwings/logs"
LOG_LEVEL: str = "INFO"   # DEBUG, INFO, WARNING, ERROR


# ════════════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════════════
def is_my_id(boat_id: str) -> bool:
    return boat_id.upper() == DRONE_ID

def is_teammate(boat_id: str) -> bool:
    bid = boat_id.upper()
    return bid in TEAM_BOATS and bid != DRONE_ID

def is_enemy(boat_id: str) -> bool:
    return boat_id.upper() in ENEMY_BOATS


if __name__ == "__main__":
    # Auto-diagnostic : afficher la config active
    print(f"=== StormWings config ===")
    print(f"DRONE_ID         = {DRONE_ID}")
    print(f"DRONE_NUM        = {DRONE_NUM}")
    print(f"DEFAULT_ROLE     = {DEFAULT_ROLE}")
    print(f"HAS_BOOST_MOTOR  = {HAS_BOOST_MOTOR}")
    print(f"MAVLINK_PORT     = {MAVLINK_PORT} @ {MAVLINK_BAUD} baud")
    print(f"LORA_PORT        = {LORA_PORT}")
    print(f"TDMA slot        = {MY_TDMA_OFFSET_MS} ms")
    print(f"Buoys            = {list(BUOYS_LOCAL.keys())}")
    print(f"Course legs      = {len(COURSE_3_LEGS)}")
