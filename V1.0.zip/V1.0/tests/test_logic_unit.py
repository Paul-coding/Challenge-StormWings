"""
Tests unitaires de la logique pure (sans matériel).

Lancer en local sur un PC pour vérifier la cohérence des modules :
    python3 -m tests.test_logic_unit
"""

import math
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from navigation import geo_utils, layline, polar, potential_field, vmg
from navigation.heading_pid import HeadingPID
from navigation.waypoints import CourseManager
from comms.protocol import (
    PositionMessage, WindMessage, parse_message, build_position_from_telemetry,
)


class TestGeoUtils(unittest.TestCase):
    def test_gps_local_roundtrip(self):
        lat0 = config.ORIGIN_LAT + 0.001
        lon0 = config.ORIGIN_LON + 0.001
        e, n = geo_utils.gps_to_local(lat0, lon0)
        lat2, lon2 = geo_utils.local_to_gps(e, n)
        self.assertAlmostEqual(lat0, lat2, places=6)
        self.assertAlmostEqual(lon0, lon2, places=6)

    def test_distance(self):
        d = geo_utils.distance_m((0, 0), (3, 4))
        self.assertAlmostEqual(d, 5.0)

    def test_bearing(self):
        # Nord
        b = geo_utils.bearing_deg((0, 0), (0, 10))
        self.assertAlmostEqual(b, 0.0)
        # Est
        b = geo_utils.bearing_deg((0, 0), (10, 0))
        self.assertAlmostEqual(b, 90.0)
        # Sud
        b = geo_utils.bearing_deg((0, 0), (0, -10))
        self.assertAlmostEqual(b, 180.0)
        # Ouest
        b = geo_utils.bearing_deg((0, 0), (-10, 0))
        self.assertAlmostEqual(b, 270.0)

    def test_angle_diff(self):
        self.assertAlmostEqual(geo_utils.angle_diff_deg(10, 350), 20.0)
        self.assertAlmostEqual(geo_utils.angle_diff_deg(350, 10), -20.0)
        # 180 est un cas limite : peut être +180 ou -180 (équivalents)
        self.assertAlmostEqual(abs(geo_utils.angle_diff_deg(180, 0)), 180.0)


class TestPolar(unittest.TestCase):
    def test_dead_zone(self):
        # Sous l'angle min → vitesse nulle
        v = polar.boat_speed_predicted(20.0, 5.0)
        self.assertAlmostEqual(v, 0.0)

    def test_speed_increases_with_wind(self):
        v1 = polar.boat_speed_predicted(60.0, 3.0)
        v2 = polar.boat_speed_predicted(60.0, 6.0)
        self.assertGreater(v2, v1)

    def test_optimal_upwind(self):
        opt = polar.optimal_upwind_angle(5.0)
        self.assertGreater(opt, 35.0)
        self.assertLess(opt, 60.0)

    def test_sail_trim_monotonic(self):
        # La voile s'ouvre quand le vent passe de la face vers l'arrière
        prev = polar.sail_trim_percent(0)
        for awa in range(10, 180, 10):
            curr = polar.sail_trim_percent(awa)
            self.assertGreaterEqual(curr, prev - 0.01)
            prev = curr


class TestVMG(unittest.TestCase):
    def test_upwind_returns_two_options(self):
        # Vent d'est (90°), waypoint à l'est (0,0 → 0,10 ?? non, à east)
        # Le waypoint est à l'est, le vent vient de l'est → upwind
        advice = vmg.compute_optimal_heading(
            boat_pos=(0, 0),
            waypoint=(50, 0),       # waypoint à l'est
            true_wind_dir_deg=90.0,  # vent d'est
            true_wind_speed_ms=5.0,
            current_heading_deg=45.0,
        )
        self.assertEqual(advice.regime, "UPWIND")
        self.assertTrue(advice.needs_tacking)

    def test_reaching(self):
        # Vent d'ouest, waypoint au nord → travers
        advice = vmg.compute_optimal_heading(
            boat_pos=(0, 0),
            waypoint=(0, 50),
            true_wind_dir_deg=270.0,
            true_wind_speed_ms=5.0,
            current_heading_deg=0.0,
        )
        self.assertEqual(advice.regime, "REACHING")

    def test_apparent_wind(self):
        # Bateau immobile → vent apparent = vent réel
        awa, awa_speed = vmg.true_to_apparent_wind(
            true_wind_dir_deg=90.0,
            true_wind_speed_ms=5.0,
            boat_heading_deg=0.0,
            boat_speed_ms=0.0,
        )
        self.assertAlmostEqual(awa_speed, 5.0)
        # AWA = vent vient à 90° du nord → bateau cap nord →
        # vent apparent vient de la droite (+90°)
        self.assertAlmostEqual(awa, 90.0, places=1)


class TestProtocol(unittest.TestCase):
    def test_position_roundtrip(self):
        msg = PositionMessage("U1B1", 43.48256, 6.49872, 185, 3.2, no_fix=False)
        text = msg.encode()
        self.assertTrue(text.startswith("P|U1B1"))
        parsed = parse_message(text)
        self.assertIsInstance(parsed, PositionMessage)
        self.assertEqual(parsed.boat_id, "U1B1")
        self.assertAlmostEqual(parsed.lat, 43.48256, places=4)
        self.assertAlmostEqual(parsed.lon, 6.49872, places=4)
        self.assertEqual(parsed.heading_deg, 185)

    def test_wind_roundtrip(self):
        msg = WindMessage(245, 6.3, 1746787652, sensor_offline=False)
        text = msg.encode()
        parsed = parse_message(text)
        self.assertIsInstance(parsed, WindMessage)
        self.assertEqual(parsed.direction_deg, 245)
        self.assertAlmostEqual(parsed.speed_ms, 6.3, places=1)

    def test_no_fix(self):
        msg = build_position_from_telemetry(
            "U1B2", 0, 0, 0, 0, has_fix=False,
        )
        self.assertTrue(msg.no_fix)
        text = msg.encode()
        self.assertEqual(text, "P|U1B2|0|0|0|0")

    def test_negative_lat_lon(self):
        # Le PDF spécifie int32 ×1e5 — peut être négatif
        msg = PositionMessage("U1B1", -43.48256, -6.49872, 0, 0, no_fix=False)
        text = msg.encode()
        parsed = parse_message(text)
        self.assertAlmostEqual(parsed.lat, -43.48256, places=4)
        self.assertAlmostEqual(parsed.lon, -6.49872, places=4)


class TestCourse(unittest.TestCase):
    def test_initial_state(self):
        cm = CourseManager()
        self.assertEqual(cm.current_idx, 0)
        self.assertFalse(cm.race_started)
        self.assertEqual(cm.current_leg.name, "DEPART")

    def test_progression(self):
        # Simuler qu'on franchit la porte A-B
        cm = CourseManager()
        # Position de départ : à l'est de la porte
        cm.update_and_validate((100.0, -15.0))
        # Position après franchissement : à l'ouest de la porte
        cm.update_and_validate((60.0, -15.0))
        self.assertTrue(cm.race_started)
        self.assertEqual(cm.current_leg.name, "ETAPE_1_C")


class TestPID(unittest.TestCase):
    def test_zero_error(self):
        pid = HeadingPID()
        out = pid.compute(target_heading_deg=90.0, current_heading_deg=90.0)
        self.assertAlmostEqual(out, 0.0)

    def test_positive_error_right_rudder(self):
        pid = HeadingPID()
        # Cap voulu 100°, cap actuel 90° → erreur +10° → safran à droite
        out = pid.compute(target_heading_deg=100.0, current_heading_deg=90.0)
        self.assertGreater(out, 0)

    def test_saturation(self):
        pid = HeadingPID()
        # Erreur énorme
        out = pid.compute(target_heading_deg=180.0, current_heading_deg=0.0)
        self.assertLessEqual(abs(out), config.RUDDER_ANGLE_MAX_DEG + 0.01)


class TestPotentialField(unittest.TestCase):
    def test_attractive_only(self):
        f = potential_field.attractive_force((0, 0), (10, 0), gain=1.0)
        # Force unitaire vers l'est
        self.assertAlmostEqual(f[0], 1.0)
        self.assertAlmostEqual(f[1], 0.0)

    def test_repulsive_close(self):
        rep = potential_field.Repulsor(pos=(2, 0), radius_m=4.0, gain=10.0)
        f = potential_field.repulsive_force((0, 0), rep)
        # Force répulsive → bateau en (0,0), répulseur en (+2,0)
        # → force pointe vers (-1, 0) (loin du répulseur)
        self.assertLess(f[0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
