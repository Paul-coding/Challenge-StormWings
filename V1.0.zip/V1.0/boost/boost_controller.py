"""
Gestion du moteur boost électrique.

Règlement Battleboats 2026 (cf. DOSSIER_TECHNIQUE.docx) :
    - Boost moteur autorisé : Ø hélice ≤ 30 mm
    - 3 ACTIVATIONS MAX × 30 SECONDES chacune
    - À utiliser uniquement en cas de besoin (vent mort, sortie de pénalité)

Sur l'équipe UTT, seul le drone U1B1 (Scout) embarque le moteur. Le pilotage
se fait via un canal RC supplémentaire (CH4 par défaut, configurable dans
config.BOOST_RC_CHANNEL). Le Pi commande le moteur en envoyant un override
PWM sur ce canal lorsque les conditions d'activation sont réunies.

Conditions d'activation automatique :
    - Vent réel < 1.5 m/s (zone morte du Joysway)
    - Vitesse bateau < 0.3 m/s pendant > 15 secondes
    - Direction du waypoint dans le secteur de vent (impossible sans boost)

Sécurités :
    - Refuse d'activer si activations restantes = 0
    - Refuse d'activer si batterie < 25%
    - Coupe automatiquement après 30 s
    - Coupe immédiatement si la vitesse remonte au-dessus de 1.0 m/s
      (le boost a fait son office)
"""

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import config
from comms.mavlink_iface import MavlinkInterface

log = logging.getLogger(__name__)


class BoostState(Enum):
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    EXHAUSTED = "EXHAUSTED"   # 3 activations consommées
    DISABLED = "DISABLED"     # drone sans boost


@dataclass
class BoostStatus:
    state: BoostState
    activations_used: int
    activations_remaining: int
    current_runtime_s: float
    total_runtime_s: float
    last_activation_t: float


class BoostController:
    """Pilote le moteur boost (uniquement sur les drones qui en sont équipés)."""

    MAX_ACTIVATIONS = 3
    MAX_DURATION_S = 30.0
    LOW_SPEED_THRESHOLD_MS = 0.3
    HIGH_SPEED_CUTOFF_MS = 1.0          # vitesse à laquelle on coupe le boost
    MIN_LOW_SPEED_DURATION_S = 15.0     # délai avant éligibilité
    MIN_BATTERY_PCT = 25.0
    MIN_WIND_FOR_NO_BOOST_MS = 1.5      # vent mort si < cette valeur

    def __init__(self, mav: Optional[MavlinkInterface] = None):
        self.mav = mav
        self._has_boost = config.HAS_BOOST_MOTOR
        self._state = BoostState.IDLE if self._has_boost else BoostState.DISABLED
        self._activations_used: int = 0
        self._total_runtime: float = 0.0
        self._activation_start_t: float = 0.0
        self._low_speed_since_t: float = 0.0
        self._last_high_speed_t: float = time.monotonic()

    @property
    def has_boost(self) -> bool:
        return self._has_boost

    @property
    def state(self) -> BoostState:
        return self._state

    @property
    def remaining_activations(self) -> int:
        return max(0, self.MAX_ACTIVATIONS - self._activations_used)

    # ─────────────────────────────────────────────
    # API publique
    # ─────────────────────────────────────────────
    def update(self, boat_speed_ms: float, wind_speed_ms: float,
               battery_pct: float,
               role_authorizes: bool = True) -> BoostStatus:
        """À appeler à chaque tick navigation."""
        now = time.monotonic()

        if not self._has_boost or self._state == BoostState.DISABLED:
            return self._status(now)

        # Suivi de la vitesse pour détecter les conditions d'éligibilité
        if boat_speed_ms < self.LOW_SPEED_THRESHOLD_MS:
            if self._low_speed_since_t == 0.0:
                self._low_speed_since_t = now
        else:
            self._low_speed_since_t = 0.0
            if boat_speed_ms > self.HIGH_SPEED_CUTOFF_MS:
                self._last_high_speed_t = now

        # Si le boost tourne, vérifier les conditions de coupure
        if self._state == BoostState.RUNNING:
            runtime = now - self._activation_start_t
            if runtime >= self.MAX_DURATION_S:
                self._stop("durée max 30s atteinte")
            elif boat_speed_ms > self.HIGH_SPEED_CUTOFF_MS:
                # Le boost a redonné de la vitesse → on coupe pour économiser
                self._stop("vitesse > %.1f m/s" % self.HIGH_SPEED_CUTOFF_MS)
            elif battery_pct < self.MIN_BATTERY_PCT:
                self._stop("batterie < %.0f%%" % self.MIN_BATTERY_PCT)

        return self._status(now)

    def request_boost(self, boat_speed_ms: float, wind_speed_ms: float,
                      battery_pct: float, reason: str = "auto") -> bool:
        """Demande explicite de boost. Retourne True si activation effective."""
        now = time.monotonic()

        if not self._has_boost:
            return False

        if self._state == BoostState.RUNNING:
            log.debug("[BOOST] Déjà en cours")
            return False

        if self.remaining_activations <= 0:
            self._state = BoostState.EXHAUSTED
            log.warning("[BOOST] Toutes les activations consommées (%d)",
                        self._activations_used)
            return False

        if battery_pct < self.MIN_BATTERY_PCT:
            log.warning(
                "[BOOST] Refus : batterie %.1f%% < %.0f%%",
                battery_pct, self.MIN_BATTERY_PCT,
            )
            return False

        # Activation effective
        self._activations_used += 1
        self._activation_start_t = now
        self._state = BoostState.RUNNING
        log.warning(
            "[BOOST] ON — activation %d/%d (raison=%s, vent=%.2fm/s, vitesse=%.2fm/s)",
            self._activations_used, self.MAX_ACTIVATIONS,
            reason, wind_speed_ms, boat_speed_ms,
        )

        # Envoi PWM ON sur le canal CH4
        if self.mav is not None:
            self.mav.set_aux_pwm(config.BOOST_RC_CHANNEL, config.BOOST_PWM_ON)

        return True

    def auto_check(self, boat_speed_ms: float, wind_speed_ms: float,
                   battery_pct: float, in_dead_zone: bool,
                   role_authorizes: bool) -> bool:
        """Décide automatiquement s'il faut activer le boost.

        Conditions cumulatives :
            - Pas déjà actif
            - Vent < seuil OU dans la zone morte
            - Vitesse < seuil depuis MIN_LOW_SPEED_DURATION_S
            - Activations restantes > 0
            - Batterie OK
            - Rôle autorisé (Scout uniquement par défaut)
        """
        if not self._has_boost or not role_authorizes:
            return False
        if self._state != BoostState.IDLE:
            return False
        if self.remaining_activations <= 0:
            return False
        if battery_pct < self.MIN_BATTERY_PCT:
            return False
        # Vent ou zone morte
        if wind_speed_ms >= self.MIN_WIND_FOR_NO_BOOST_MS and not in_dead_zone:
            return False
        # Bateau bloqué depuis assez longtemps
        if self._low_speed_since_t == 0.0:
            return False
        low_duration = time.monotonic() - self._low_speed_since_t
        if low_duration < self.MIN_LOW_SPEED_DURATION_S:
            return False

        return self.request_boost(
            boat_speed_ms, wind_speed_ms, battery_pct, reason="auto-vent-mort",
        )

    def stop(self, reason: str = "manuel"):
        """Arrêt manuel du boost (sortie de zone morte, etc.)."""
        self._stop(reason)

    def reset(self):
        """À appeler entre 2 courses."""
        self._activations_used = 0
        self._total_runtime = 0.0
        self._state = BoostState.IDLE if self._has_boost else BoostState.DISABLED
        if self.mav is not None:
            self.mav.clear_aux_pwm(config.BOOST_RC_CHANNEL)

    # ─────────────────────────────────────────────
    # Privé
    # ─────────────────────────────────────────────
    def _stop(self, reason: str):
        if self._state != BoostState.RUNNING:
            return
        runtime = time.monotonic() - self._activation_start_t
        self._total_runtime += runtime
        log.warning(
            "[BOOST] OFF — durée=%.1fs (raison=%s, total=%.1fs)",
            runtime, reason, self._total_runtime,
        )
        if self._activations_used >= self.MAX_ACTIVATIONS:
            self._state = BoostState.EXHAUSTED
        else:
            self._state = BoostState.IDLE
        if self.mav is not None:
            self.mav.set_aux_pwm(config.BOOST_RC_CHANNEL, config.BOOST_PWM_OFF)

    def _status(self, now: float) -> BoostStatus:
        runtime = (now - self._activation_start_t) if self._state == BoostState.RUNNING else 0.0
        return BoostStatus(
            state=self._state,
            activations_used=self._activations_used,
            activations_remaining=self.remaining_activations,
            current_runtime_s=runtime,
            total_runtime_s=self._total_runtime,
            last_activation_t=self._activation_start_t,
        )
