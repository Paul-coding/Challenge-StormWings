"""
Modes dégradés (cf. dossier technique §XV.2).

Surveille les pannes possibles et bascule la stratégie en conséquence :
    - Perte GNSS RTK fix       → mode estime (dead-reckoning)
    - Perte communication LoRa → navigation solo sans coordination
    - Perte vent Calypso       → utilise l'historique ou valeurs par défaut
    - Batterie < 20%           → shortcut vers l'arrivée
    - Heartbeat Cube perdu     → libération override + alerte

L'objectif : ne JAMAIS s'arrêter complètement, dégrader proprement.
"""

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List

import config

log = logging.getLogger(__name__)


class DegradedMode(Enum):
    NOMINAL = "NOMINAL"
    GPS_DEGRADED = "GPS_DEGRADED"           # GPS standard, plus de RTK
    GPS_LOST = "GPS_LOST"                   # plus aucun fix → estime
    LORA_LOST = "LORA_LOST"                 # plus de comm essaim
    WIND_STALE = "WIND_STALE"               # plus de Calypso
    LOW_BATTERY = "LOW_BATTERY"             # < 20%
    MAVLINK_LOST = "MAVLINK_LOST"           # heartbeat Cube perdu (CRITIQUE)


@dataclass
class DegradedState:
    active_modes: List[DegradedMode] = field(default_factory=list)
    severity: int = 0       # 0 = nominal, 1 = warning, 2 = critique

    def has(self, mode: DegradedMode) -> bool:
        return mode in self.active_modes


class DegradedManager:
    """Surveille les capteurs et publie un état de dégradation global."""

    LOW_BATTERY_PCT = 20.0
    GPS_FIX_MIN = 3            # 3 = 3D fix, 6 = RTK fix

    def __init__(self):
        self._state = DegradedState()

    def update(self,
               has_gps_fix: bool,
               gps_fix_type: int,
               last_gps_age_s: float,
               wind_age_s: float,
               wind_confident: bool,
               num_active_neighbors: int,
               battery_pct: float,
               mavlink_alive: bool) -> DegradedState:
        modes: List[DegradedMode] = []
        severity = 0

        if not mavlink_alive:
            modes.append(DegradedMode.MAVLINK_LOST)
            severity = max(severity, 2)

        if not has_gps_fix or last_gps_age_s > config.GPS_FIX_TIMEOUT_S:
            modes.append(DegradedMode.GPS_LOST)
            severity = max(severity, 2)
        elif gps_fix_type < 6:
            # Fix 3D mais pas RTK → précision dégradée mais utilisable
            modes.append(DegradedMode.GPS_DEGRADED)
            severity = max(severity, 1)

        if num_active_neighbors == 0:
            modes.append(DegradedMode.LORA_LOST)
            severity = max(severity, 1)

        if not wind_confident or wind_age_s > config.WIND_FALLBACK_TIMEOUT_S:
            modes.append(DegradedMode.WIND_STALE)
            severity = max(severity, 1)

        if battery_pct < self.LOW_BATTERY_PCT:
            modes.append(DegradedMode.LOW_BATTERY)
            severity = max(severity, 1)

        # Diff par rapport à l'état précédent → log uniquement si changement
        prev = set(m.value for m in self._state.active_modes)
        curr = set(m.value for m in modes)
        if prev != curr:
            for m in (curr - prev):
                log.warning("[DEGRADED] Activation : %s", m)
            for m in (prev - curr):
                log.info("[DEGRADED] Résolution : %s", m)

        self._state = DegradedState(active_modes=modes, severity=severity)
        return self._state

    @property
    def state(self) -> DegradedState:
        return self._state
